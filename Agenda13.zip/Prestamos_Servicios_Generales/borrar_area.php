<?php
//algoritmo para borrar area de adscripcion

?>