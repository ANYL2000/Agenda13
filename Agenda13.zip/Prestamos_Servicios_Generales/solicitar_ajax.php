<?php

$nombres = $_POST['nombres_personas'];

print($nombres);

echo $nombres;

?>